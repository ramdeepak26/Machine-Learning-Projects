"""
Render a trained LunarLander DQN/Double-DQN agent playing, and save it as a GIF.

Usage:
    python lunarlander_render.py --ddqn       # for the Double DQN model
    python lunarlander_render.py              # for the standard DQN model
"""

import argparse
import torch
import gymnasium as gym
import imageio

from lunarlander_dqn import QNetwork


NUM_EPISODES_TO_RECORD = 3
MAX_STEPS_PER_EPISODE = 1000


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ddqn", action="store_true", help="Render the Double DQN model")
    args = parser.parse_args()

    model_path = "lunarlander_ddqn.pth" if args.ddqn else "lunarlander_dqn.pth"
    output_gif = "lunarlander_ddqn_agent.gif" if args.ddqn else "lunarlander_dqn_agent.gif"

    device = torch.device("cpu")

    env = gym.make("LunarLander-v3", render_mode="rgb_array")
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    policy_net = QNetwork(state_dim, action_dim).to(device)
    policy_net.load_state_dict(torch.load(model_path, map_location=device))
    policy_net.eval()

    frames = []

    for ep in range(NUM_EPISODES_TO_RECORD):
        state, _ = env.reset(seed=2000 + ep)
        total_reward = 0
        done = False
        steps = 0

        while not done and steps < MAX_STEPS_PER_EPISODE:
            frame = env.render()
            frames.append(frame)

            with torch.no_grad():
                state_t = torch.as_tensor(state, dtype=torch.float32).unsqueeze(0)
                action = int(torch.argmax(policy_net(state_t), dim=1).item())

            state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            total_reward += reward
            steps += 1

        print(f"Episode {ep + 1}: reward = {total_reward:.1f}")

    env.close()

    print(f"Saving {len(frames)} frames to {output_gif} ...")
    imageio.mimsave(output_gif, frames, fps=30)
    print("Done.")


if __name__ == "__main__":
    main()
