# LunarLander-v3: Double DQN

An agent that learns to land a spacecraft between two flags in Gymnasium's
`LunarLander-v3` environment, trained from scratch using **Double DQN**.

![Trained agent landing](lunarlander_ddqn_agent.gif)

## The environment

LunarLander gives the agent 8 continuous state values (position, velocity,
angle, angular velocity, and two leg-ground-contact flags) and 4 discrete
actions (do nothing, fire left engine, fire main engine, fire right engine).
The agent is rewarded for moving toward the landing pad, penalized for
crashing or firing engines, and gets a large bonus for landing safely. The
environment is considered "solved" at an average reward of 200 over 100
episodes.

## Method

- **Algorithm**: Double DQN ([van Hasselt et al., 2015](https://arxiv.org/abs/1509.06461)),
  which fixes a known weakness of standard DQN — it tends to overestimate
  Q-values because the same network both picks and evaluates the best next
  action. Double DQN splits this: the policy network picks the action, the
  target network evaluates it.
- **Experience replay**: a 100,000-transition buffer, sampled in mini-batches
  of 128, to break correlation between consecutive steps.
- **Target network**: synced with the policy network every 1,000 steps for
  stable training targets.
- **Epsilon-greedy exploration**: decays linearly from 1.0 to 0.01 over the
  first 50,000 steps.
- **Network**: a 3-layer MLP (8 → 256 → 256 → 4) with ReLU activations.

## Solving criterion

We use a two-part criterion over the last 100 episodes, stricter than the
single mean-based check Gymnasium documents:
1. **Mean return ≥ 200**
2. **Minimum return in the window ≥ 100** (guards against calling it "solved"
   right after a lucky streak while occasional bad crashes are still common)

In our training run, the agent reached a 100-episode average of ~205 by
episode 1000, with most recent episodes landing in the 250–300 range.

## Files

- [`lunarlander_dqn.py`](lunarlander_dqn.py) — training script. Run with
  `--ddqn` for Double DQN (recommended, used for the included model) or
  without it for plain DQN.
- [`lunarlander_render.py`](lunarlander_render.py) — loads a trained model and
  renders it playing, saving the result as a GIF.
- [`lunarlander_ddqn.pth`](lunarlander_ddqn.pth) — trained model weights.
- [`lunarlander_ddqn_rewards.png`](lunarlander_ddqn_rewards.png) — reward curve
  over training.
- [`lunarlander_ddqn_agent.gif`](lunarlander_ddqn_agent.gif) — simulation of
  the trained agent landing.

## Quickstart

```bash
pip install -r requirements.txt

# Train a new agent from scratch (Double DQN)
python lunarlander_dqn.py --ddqn

# Or train plain DQN instead
python lunarlander_dqn.py

# Render the trained agent playing
python lunarlander_render.py --ddqn
```

Training runs for up to 1000 episodes by default (override with
`--episodes N`), and stops early if the solving criterion above is met.

## References

- Mnih et al., *Playing Atari with Deep Reinforcement Learning*, [arXiv:1312.5602](https://arxiv.org/abs/1312.5602)
- van Hasselt, Guez, Silver, *Deep Reinforcement Learning with Double Q-learning*, [arXiv:1509.06461](https://arxiv.org/abs/1509.06461)
- [Gymnasium LunarLander-v3 docs](https://gymnasium.farama.org/environments/box2d/lunar_lander/)
