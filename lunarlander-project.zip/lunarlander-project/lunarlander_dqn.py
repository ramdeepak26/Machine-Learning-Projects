"""
DQN / Double DQN for LunarLander-v3 using Gymnasium.

Usage:
    python lunarlander_dqn.py            # standard DQN
    python lunarlander_dqn.py --ddqn      # Double DQN (reduces Q-value
                                           # overestimation, see
                                           # https://arxiv.org/abs/1509.06461)

Same recipe as CartPole (experience replay + target network + epsilon-greedy),
just with a bigger network and more training episodes since LunarLander is a
harder environment (continuous physics, sparse landing reward).

Solving criterion: LunarLander-v3 is considered solved when the agent scores
at least 200 on average. We use a slightly stricter two-part version of this,
requiring BOTH the minimum and the mean return over the last N_SOLVING_EPISODES
episodes to clear a threshold -- this avoids calling it "solved" right after
a lucky streak while a bad landing is still common.
"""

import argparse
import random
import collections
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import gymnasium as gym
import matplotlib.pyplot as plt


# ---------------------------
# Hyperparameters
# ---------------------------
ENV_NAME = "LunarLander-v3"
NUM_EPISODES = 1000
GAMMA = 0.99
LR = 5e-4
BATCH_SIZE = 128
REPLAY_CAPACITY = 100000
MIN_REPLAY_SIZE = 2000
EPSILON_START = 1.0
EPSILON_END = 0.01
EPSILON_DECAY_STEPS = 50000
TARGET_UPDATE_FREQ = 1000

# Two-part solving criterion (evaluated over the last N_SOLVING_EPISODES)
N_SOLVING_EPISODES = 100
SOLVING_THRESHOLD_MEAN = 200   # average return must exceed this...
SOLVING_THRESHOLD_MIN = 100    # ...and the worst episode in the window must too

SEED = 42


# ---------------------------
# Q-Network
# ---------------------------
class QNetwork(nn.Module):
    def __init__(self, state_dim, action_dim, hidden=256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, action_dim),
        )

    def forward(self, x):
        return self.net(x)


# ---------------------------
# Replay Buffer
# ---------------------------
class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = collections.deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        return (
            np.array(states, dtype=np.float32),
            np.array(actions, dtype=np.int64),
            np.array(rewards, dtype=np.float32),
            np.array(next_states, dtype=np.float32),
            np.array(dones, dtype=np.float32),
        )

    def __len__(self):
        return len(self.buffer)


def epsilon_by_step(step):
    frac = min(1.0, step / EPSILON_DECAY_STEPS)
    return EPSILON_START + frac * (EPSILON_END - EPSILON_START)


def select_action(policy_net, state, epsilon, action_dim, device):
    if random.random() < epsilon:
        return random.randrange(action_dim)
    with torch.no_grad():
        state_t = torch.as_tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
        q_values = policy_net(state_t)
        return int(torch.argmax(q_values, dim=1).item())


def train_step(policy_net, target_net, optimizer, buffer, device, use_ddqn=False):
    states, actions, rewards, next_states, dones = buffer.sample(BATCH_SIZE)

    states = torch.as_tensor(states, device=device)
    actions = torch.as_tensor(actions, device=device)
    rewards = torch.as_tensor(rewards, device=device)
    next_states = torch.as_tensor(next_states, device=device)
    dones = torch.as_tensor(dones, device=device)

    q_values = policy_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)

    with torch.no_grad():
        if use_ddqn:
            # Double DQN: pick the best next action using the POLICY net,
            # but evaluate its Q-value using the TARGET net. This decouples
            # action selection from action evaluation and reduces the
            # over-optimistic Q-value estimates plain DQN is prone to.
            best_next_actions = policy_net(next_states).argmax(dim=1)
            next_q_values = target_net(next_states).gather(
                1, best_next_actions.unsqueeze(1)
            ).squeeze(1)
        else:
            next_q_values = target_net(next_states).max(dim=1)[0]
        targets = rewards + GAMMA * next_q_values * (1 - dones)

    loss = nn.functional.smooth_l1_loss(q_values, targets)

    optimizer.zero_grad()
    loss.backward()
    torch.nn.utils.clip_grad_norm_(policy_net.parameters(), 10.0)
    optimizer.step()

    return loss.item()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--ddqn", action="store_true",
        help="Use Double DQN instead of standard DQN",
    )
    parser.add_argument(
        "--episodes", type=int, default=NUM_EPISODES,
        help=f"Number of training episodes (default: {NUM_EPISODES})",
    )
    args = parser.parse_args()
    use_ddqn = args.ddqn
    num_episodes = args.episodes

    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    print(f"Algorithm: {'Double DQN' if use_ddqn else 'DQN'}")

    env = gym.make(ENV_NAME)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    policy_net = QNetwork(state_dim, action_dim).to(device)
    target_net = QNetwork(state_dim, action_dim).to(device)
    target_net.load_state_dict(policy_net.state_dict())
    target_net.eval()

    optimizer = optim.Adam(policy_net.parameters(), lr=LR)
    buffer = ReplayBuffer(REPLAY_CAPACITY)

    episode_rewards = []
    global_step = 0

    for episode in range(1, num_episodes + 1):
        state, _ = env.reset(seed=SEED + episode)
        episode_reward = 0.0
        done = False

        while not done:
            epsilon = epsilon_by_step(global_step)
            action = select_action(policy_net, state, epsilon, action_dim, device)

            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            buffer.push(state, action, reward, next_state, float(done))
            state = next_state
            episode_reward += reward
            global_step += 1

            if len(buffer) >= MIN_REPLAY_SIZE:
                train_step(policy_net, target_net, optimizer, buffer, device, use_ddqn)

            if global_step % TARGET_UPDATE_FREQ == 0:
                target_net.load_state_dict(policy_net.state_dict())

        episode_rewards.append(episode_reward)
        window = episode_rewards[-N_SOLVING_EPISODES:]
        avg_recent = np.mean(window)
        min_recent = np.min(window)

        if episode % 10 == 0:
            print(
                f"Episode {episode:4d} | Reward: {episode_reward:7.1f} | "
                f"Avg({N_SOLVING_EPISODES}): {avg_recent:7.1f} | "
                f"Min({N_SOLVING_EPISODES}): {min_recent:7.1f} | Epsilon: {epsilon:.3f}"
            )

        if (
            len(episode_rewards) >= N_SOLVING_EPISODES
            and avg_recent >= SOLVING_THRESHOLD_MEAN
            and min_recent >= SOLVING_THRESHOLD_MIN
        ):
            print(
                f"\nSolved at episode {episode}! "
                f"Avg({N_SOLVING_EPISODES}) = {avg_recent:.1f}, "
                f"Min({N_SOLVING_EPISODES}) = {min_recent:.1f}"
            )
            break

    env.close()

    model_path = "lunarlander_ddqn.pth" if use_ddqn else "lunarlander_dqn.pth"
    torch.save(policy_net.state_dict(), model_path)
    print(f"Saved trained model to {model_path}")

    algo_name = "Double DQN" if use_ddqn else "DQN"
    plot_path = "lunarlander_ddqn_rewards.png" if use_ddqn else "lunarlander_dqn_rewards.png"

    plt.figure(figsize=(10, 5))
    plt.plot(episode_rewards, alpha=0.4, label="Episode reward")
    if len(episode_rewards) >= 10:
        w = 10
        moving_avg = np.convolve(episode_rewards, np.ones(w) / w, mode="valid")
        plt.plot(range(w - 1, len(episode_rewards)), moving_avg, label="Moving avg (10)")
    plt.axhline(y=SOLVING_THRESHOLD_MEAN, color="green", linestyle="--", label="Solved threshold (mean)")
    plt.xlabel("Episode")
    plt.ylabel("Reward")
    plt.title(f"{algo_name} on LunarLander-v3")
    plt.legend()
    plt.tight_layout()
    plt.savefig(plot_path, dpi=150)
    print(f"Saved reward plot to {plot_path}")


if __name__ == "__main__":
    main()
