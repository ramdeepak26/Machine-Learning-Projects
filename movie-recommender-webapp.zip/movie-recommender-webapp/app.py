import os
from flask import Flask, render_template, request, jsonify

from recommender import Recommender

app = Flask(__name__)

DATA_PATH = os.path.join(os.path.dirname(__file__), "movies.csv")
engine = Recommender(DATA_PATH)


@app.route("/")
def index():
    return render_template("index.html", titles=engine.all_titles())


@app.route("/recommend")
def recommend():
    title = request.args.get("title", "").strip()
    if not title:
        return jsonify({"error": "No title provided"}), 400

    results = engine.recommend(title, n=8)
    if results is None:
        return jsonify({"error": f'"{title}" not found in catalog'}), 404

    return jsonify({"query": title, "results": results})


if __name__ == "__main__":
    app.run(debug=True)
