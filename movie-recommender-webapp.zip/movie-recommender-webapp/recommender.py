"""
Content-based recommendation engine.
Same approach as the standalone script: TF-IDF over genres, cosine similarity.
"""

import os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel


class Recommender:
    def __init__(self, csv_path: str):
        self.movies = pd.read_csv(csv_path)
        self.movies["genres_clean"] = (
            self.movies["genres"]
            .replace("(no genres listed)", "")
            .str.replace("|", " ", regex=False)
        )

        self.vectorizer = TfidfVectorizer(stop_words="english", token_pattern=r"[^\s]+")
        self.tfidf_matrix = self.vectorizer.fit_transform(self.movies["genres_clean"])

        self.title_to_index = pd.Series(
            self.movies.index, index=self.movies["title"]
        )

    def all_titles(self):
        return self.movies["title"].tolist()

    def recommend(self, title: str, n: int = 8):
        if title not in self.title_to_index:
            return None

        idx = self.title_to_index[title]
        sims = linear_kernel(self.tfidf_matrix[idx], self.tfidf_matrix).flatten()
        ranked = sims.argsort()[::-1]
        ranked = [i for i in ranked if i != idx][:n]

        results = []
        for rank, i in enumerate(ranked, start=1):
            row = self.movies.iloc[i]
            results.append({
                "rank": rank,
                "title": row["title"],
                "genres": row["genres"].replace("|", " / "),
                "score": round(float(sims[i]) * 100),
            })
        return results
